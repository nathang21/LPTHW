x = "This is Python"
ver = 2.7
print "Hello World", x, ver
